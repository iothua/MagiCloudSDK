﻿namespace Loxodon.Framework.Bundles
{
    public interface ITaskExecutor
    {
        void Execute(ITask task);
    }
}
