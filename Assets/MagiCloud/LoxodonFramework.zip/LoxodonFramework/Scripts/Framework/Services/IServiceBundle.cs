﻿namespace Loxodon.Framework.Services
{
    public interface IServiceBundle
    {
        void Start();

        void Stop();
    }
}
