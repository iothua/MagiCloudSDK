﻿namespace Loxodon.Framework.Services
{
    public interface IServiceContainer : IServiceLocator, IServiceRegistry
    {
    }
}
