﻿
namespace Loxodon.Log
{
    public enum Level
    {
        ALL = 0,
        DEBUG,
        INFO,
        WARN,
        ERROR,
        FATAL,
        OFF
    }
}
