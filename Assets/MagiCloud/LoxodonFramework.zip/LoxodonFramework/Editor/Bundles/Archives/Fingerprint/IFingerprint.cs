﻿#if UNITY_EDITOR
namespace Loxodon.Framework.Bundles.Archives
{
    public interface IFingerprint
    {
    }
}
#endif